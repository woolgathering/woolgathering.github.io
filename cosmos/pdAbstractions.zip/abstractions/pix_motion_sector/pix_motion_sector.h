#include "Base/GemPixObj.h"

class GEM_EXTERN pix_motion_sector : public GemPixObj
{
    CPPEXTERN_HEADER(pix_motion_sector, GemPixObj)
		
public:
	
	//////////
	// Constructor
	pix_motion_sector();
	
protected:
	
	//////////
	// Destructor
	virtual ~pix_motion_sector();
	
	//////////
	// Do the processing
	virtual void 	processRGBAImage(imageStruct &image);
	virtual void 	processYUVImage(imageStruct &image);
	virtual void 	processGrayImage(imageStruct &image);
#ifdef __MMX__
        virtual void 	processGrayMMX(imageStruct &image);
#endif

#ifdef __VEC__
        virtual void 	processYUVAltivec(imageStruct &image);
#endif

	//////////
	// Set the thresh
	void thresh_fMess(int argc, t_atom *argv);
    	
	//////////
	// Set the coordinates
	void coordMess(int argc, t_atom *argv);

	//////////
	// the last image (grey-scale)
	imageStruct    buffer;
	//////////
	// the movement-mode
	int x_origin, y_origin, x_depth, y_depth;
	float thresh_f;
	
	t_outlet *outlet_ratio;
	//int j,index, averageTime;
	
	//////////
	// the methods
	static void thresh_fMessCallback(void *data, t_symbol *, int argc, t_atom *argv);
	static void coordMessCallback(void *data, t_symbol *, int argc, t_atom *argv);
};