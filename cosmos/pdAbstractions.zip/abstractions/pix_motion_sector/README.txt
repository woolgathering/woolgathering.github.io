pix_motion_sector
************************

Throw the pix_motion_sector folder in Pd's Contents/Resources/extra directory.  The provided macintosh binary should work as-is. To build, cd to the pix_motion_sector directory and type "make".  Thanks to Hans-Cristoph Steiner for the makefile....