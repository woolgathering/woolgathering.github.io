/*

Detects motion in a specified sector of a video raster.

Adapted from pix_movement.

William Brent 2008

version 0.0.2, May 14, 2010

��Cleaned up a lot of the original mess. difference between frames is now computed using the complete RGB values, not their grayscale approximations. In order to match [pix_crop], changed the coords argument order so that depth is first, then origin.

*/

////////////////////////////////////////////////////////
//
// GEM - Graphics Environment for Multimedia
//
// zmoelnig@iem.kug.ac.at
//
// Implementation file
//
//    Copyright (c) 1997-1998 Mark Danks.
//    Copyright (c) G�nther Geiger.
//    Copyright (c) 2001-2002 IOhannes m zmoelnig. forum::f�r::uml�ute. IEM
//    For information on usage and redistribution, and for a DISCLAIMER OF ALL
//    WARRANTIES, see the file, "GEM.LICENSE.TERMS" in this distribution.
//
/////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////
//
// pix_motion_sector
//
//
/////////////////////////////////////////////////////////

#include "pix_motion_sector.h"
#include <string.h>
#include <math.h>
#include <time.h>
#ifdef __APPLE__
# include <Carbon/Carbon.h>
#endif

CPPEXTERN_NEW(pix_motion_sector)

/////////////////////////////////////////////////////////
//
// pix_motion_sector
//
/////////////////////////////////////////////////////////
// Constructor
//
/////////////////////////////////////////////////////////
pix_motion_sector :: pix_motion_sector()
{
	inlet_new(this->x_obj, &this->x_obj->ob_pd, gensym("float"), gensym("thresh_f"));
    inlet_new(this->x_obj, &this->x_obj->ob_pd, gensym("list"), gensym("coord"));
	
	buffer.xsize  = buffer.ysize = 64;
	buffer.format = GL_LUMINANCE;
	buffer.csize  = 1;
	buffer.reallocate();

    outlet_ratio = outlet_new(this->x_obj, gensym("float"));

	thresh_f = 15.0;

	x_origin = 0;
	y_origin = 0;
	x_depth = 0;
	y_depth = 0;
}

/////////////////////////////////////////////////////////
// Destructor
//
/////////////////////////////////////////////////////////
pix_motion_sector :: ~pix_motion_sector()
{
  // clean my buffer
}

/////////////////////////////////////////////////////////
// processImage
//
/////////////////////////////////////////////////////////
void pix_motion_sector :: processRGBAImage(imageStruct &image)
{
	int x, y, xd, yd, xo, yo, skipsize;
	float total_hits;
	unsigned char *rp, *wp;

	xd = x_depth;
	yd = y_depth;
	xo = x_origin;
	yo = image.ysize-y_origin;
		
	// correct for depth overflow
	if((xo+xd)>(image.xsize))
		xd -= (xo+xd)-image.xsize;

	if((yo+yd)>(image.ysize))
		yd -= (yo+yd)-image.ysize;

	if(xd<0)
		xd = 0;
	
	if(yd<0)
		yd = 0;

	buffer.xsize = xd*3;
	buffer.ysize = yd*3;
	buffer.reallocate();

	total_hits = 0.0;	
	rp = image.data;  // read pointer
	wp = buffer.data;  // write pointer
		
	rp += ((yo * image.xsize) + xo) * 4;  // adds a full row of Xs for every Y, *4 to accomodate RGBA data
		
	skipsize = (image.xsize-xd)*4;
	
	// move forward a full row of Xs, but exactly x_depth less, because that's the amount we've already traversed.
	for(y=yo; y<yo+yd; y++, rp += skipsize)
	{
		for(x=xo; x<xo+xd; x++)
		{
			float diff;
			
			diff = 0.0;
			diff += pow(rp[chRed] - *wp++, 2);
			diff += pow(rp[chGreen] - *wp++, 2);
			diff += pow(rp[chBlue] - *wp++, 2);
			diff = sqrt(diff);

			if( rp[chAlpha] = 255*(diff>thresh_f) )
				total_hits++;
				
			wp -= 3;
			
			*wp++ = rp[chRed];
			*wp++ = rp[chGreen];
			*wp++ = rp[chBlue];

			rp += 4;
		}
	};
		
	total_hits = total_hits/(xd*(float)yd);
	outlet_float(outlet_ratio, total_hits);
};

void pix_motion_sector :: processYUVImage(imageStruct &image)
{ error("YUV doesn't work"); };

#ifdef __VEC__
void pix_motion_sector :: processYUVAltivec(imageStruct &image)
{ error("YUV Altivec doesn't work"); };
#endif /* __VEC__ */

void pix_motion_sector :: processGrayImage(imageStruct &image)
{ error("Gray Image doesn't work"); };

#ifdef __MMX__
void pix_motion_sector :: processGrayMMX(imageStruct &image)
{ error("MMX doesn't work"); };
#endif

/////////////////////////////////////////////////////////
// thresh_fMess
//
/////////////////////////////////////////////////////////
void pix_motion_sector :: thresh_fMess(int argc, t_atom *argv)
{
	thresh_f = atom_getfloat(&argv[0]);
	
	setPixModified();
}

/////////////////////////////////////////////////////////
// coordMess
//
/////////////////////////////////////////////////////////
void pix_motion_sector :: coordMess(int argc, t_atom *argv)
{
	x_depth = (int)atom_getfloat(&argv[0]);
	y_depth = (int)atom_getfloat(&argv[1]);
	x_origin = (int)atom_getfloat(&argv[2]);
	y_origin = (int)atom_getfloat(&argv[3]);
	
	setPixModified();
}


/////////////////////////////////////////////////////////
// static member function
//
/////////////////////////////////////////////////////////
void pix_motion_sector :: obj_setupCallback(t_class *classPtr)
{
	class_addmethod(
		classPtr,
		(t_method)&pix_motion_sector::thresh_fMessCallback,
		gensym("thresh_f"),
		A_GIMME,
		A_NULL
	);

    class_addmethod(
    	classPtr,
    	(t_method)&pix_motion_sector::coordMessCallback,
		gensym("coord"),
		A_GIMME,
		A_NULL
	);		
}

void pix_motion_sector :: thresh_fMessCallback(void *data, t_symbol *, int argc, t_atom *argv)
{
    GetMyClass(data)->thresh_fMess(argc, argv);
}

void pix_motion_sector :: coordMessCallback(void *data, t_symbol *, int argc, t_atom *argv)
{
    GetMyClass(data)->coordMess(argc, argv);
}