To install convolve, drop the entire convolve folder into Pd vanilla's Contents/Resources/extra folder. The provided Macintosh binary should work on any intel Mac.

If you downloaded the source package, to build the externs on Linux (or Macintosh), cd to extra/convolve and type "make".  It requires no additional libraries and should build on Windows as well.